#!/usr/bin/env bash
SERVER_URL="${SERVER_URL:-http://127.0.0.1:2278}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-30}"
ROOT="/var/lib/commercial-monitor-pro"
STATE="$ROOT/state.env"
INV_STATE="$ROOT/inventory_state.json"
ISP_STATE="$ROOT/isp_state.json"
mkdir -p "$ROOT"

read_bytes(){ cat "/sys/class/net/$1/statistics/$2" 2>/dev/null || echo 0; }
json_escape(){ python3 -c 'import json,sys; print(json.dumps(sys.stdin.read().strip()))'; }
get_cpu_percent(){
  read cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
  idle1=$((idle+iowait)); total1=$((user+nice+system+idle+iowait+irq+softirq+steal)); sleep 1
  read cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
  idle2=$((idle+iowait)); total2=$((user+nice+system+idle+iowait+irq+softirq+steal));
  diff_idle=$((idle2-idle1)); diff_total=$((total2-total1));
  if [ "$diff_total" -le 0 ]; then echo 0; else awk "BEGIN{printf \"%.2f\", (100*($diff_total-$diff_idle)/$diff_total)}"; fi
}
get_cpu_temp(){
  for f in /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp*_input; do
    [ -f "$f" ] || continue; v=$(cat "$f" 2>/dev/null); [ -n "$v" ] || continue
    c=$(awk "BEGIN{printf \"%.2f\", $v/1000}")
    awk "BEGIN{exit !($c>0 && $c<130)}" && { echo "$c"; return; }
  done
  if command -v sensors >/dev/null 2>&1; then sensors | awk '/Package id 0|Tctl|CPU/ {for(i=1;i<=NF;i++) if($i ~ /^\+/){gsub(/[+°C]/,"",$i); print $i; exit}}'; fi
}
get_memory_json(){ free -b | awk '/Mem:/ {printf "{\"total_gb\":%.2f,\"used_gb\":%.2f,\"free_gb\":%.2f,\"used_percent\":%.2f}",$2/1024/1024/1024,$3/1024/1024/1024,$4/1024/1024/1024,($3/$2)*100}'; }
get_disks_json(){ df -BG --output=source,target,fstype,size,used,avail,pcent | tail -n +2 | python3 -c 'import sys,json,re; out=[]
for line in sys.stdin:
 p=line.split()
 if len(p)>=6:
  def gb(x):
   try:return float(str(x).rstrip("G"))
   except:return None
  out.append({"device":p[0],"mount":p[1],"type":p[2],"total_gb":gb(p[3]),"used_gb":gb(p[4]),"free_gb":gb(p[5]),"used_percent":float(p[6].rstrip("%")) if len(p)>6 else None})
print(json.dumps(out))'; }
get_identity_json(){
  host=$(hostname)
  mb=$(cat /sys/class/dmi/id/board_serial 2>/dev/null || true)
  uuid=$(cat /sys/class/dmi/id/product_uuid 2>/dev/null || true)
  bios=$(cat /sys/class/dmi/id/product_serial 2>/dev/null || true)
  maker=$(cat /sys/class/dmi/id/sys_vendor 2>/dev/null || true)
  model=$(cat /sys/class/dmi/id/product_name 2>/dev/null || true)
  python3 - <<PY
import json
print(json.dumps({"hostname":"$host","motherboard_serial":"$mb","system_uuid":"$uuid","bios_serial":"$bios","manufacturer":"$maker","model":"$model"}))
PY
}
get_cpu_json(){
  name=$(awk -F: '/model name/ {gsub(/^ /,"",$2); print $2; exit}' /proc/cpuinfo)
  cores=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 0)
  mhz=$(awk -F: '/cpu MHz/ {gsub(/^ /,"",$2); print $2; exit}' /proc/cpuinfo)
  usage=$(get_cpu_percent); temp=$(get_cpu_temp); [ -z "$temp" ] && temp=null
  python3 - <<PY
import json
print(json.dumps({"name":"$name","cores":$cores,"threads":$cores,"current_mhz":"$mhz","max_mhz":None,"usage_percent":$usage,"temperature_c":$temp}))
PY
}
get_gpus_json(){
  if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi --query-gpu=name,memory.total,memory.used,utilization.gpu,temperature.gpu --format=csv,noheader,nounits | python3 -c 'import sys,json; out=[]
for line in sys.stdin:
 p=[x.strip() for x in line.split(",")]
 if len(p)>=5: out.append({"name":p[0],"memory_total_mb":float(p[1]),"memory_used_mb":float(p[2]),"usage_percent":float(p[3]),"temperature_c":float(p[4]),"source":"nvidia-smi"})
print(json.dumps(out))'
  elif command -v lspci >/dev/null 2>&1; then
    lspci | grep -Ei 'vga|3d|display' | python3 -c 'import sys,json; print(json.dumps([{"name":line.strip(),"memory_total_mb":None,"usage_percent":None,"temperature_c":None,"source":"lspci"} for line in sys.stdin]))'
  else echo '[]'; fi
}
get_public_internet_json(){
  python3 - "$ISP_STATE" <<'PYISP'
import sys,json,os,datetime,urllib.request
path=sys.argv[1]
def empty(src='unavailable', errors=None):
 return {'public_ip':'','isp':'','org':'','as':'','country':'','city':'','checked_at':datetime.datetime.utcnow().isoformat()+'Z','source':src,'errors':errors or []}
def save(out):
 os.makedirs(os.path.dirname(path), exist_ok=True)
 json.dump(out, open(path,'w'))
 return out
cache=None
try:
 if os.path.exists(path):
  cache=json.load(open(path))
  ts=cache.get('checked_at','').replace('Z','+00:00')
  try:
   age=datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(ts)
   if age.total_seconds()<30*60 and (cache.get('public_ip') or cache.get('isp')):
    print(json.dumps(cache)); raise SystemExit
  except SystemExit: raise
  except Exception: pass
except SystemExit: raise
except Exception:
 cache=None
errors=[]
targets=[('ipinfo','https://ipinfo.io/json'),('ip-api','http://ip-api.com/json/?fields=status,query,isp,org,as,country,city'),('ipify','https://api.ipify.org?format=json')]
for source,url in targets:
 try:
  req=urllib.request.Request(url, headers={'User-Agent':'CommercialMonitorPro-Ubuntu/5.1'})
  with urllib.request.urlopen(req, timeout=8) as r:
   d=json.loads(r.read().decode())
  if source=='ipinfo': out={'public_ip':d.get('ip',''),'isp':d.get('org',''),'org':d.get('org',''),'as':d.get('org',''),'country':d.get('country',''),'city':d.get('city',''),'checked_at':datetime.datetime.utcnow().isoformat()+'Z','source':'ipinfo'}
  elif source=='ip-api': out={'public_ip':d.get('query',''),'isp':d.get('isp',''),'org':d.get('org',''),'as':d.get('as',''),'country':d.get('country',''),'city':d.get('city',''),'checked_at':datetime.datetime.utcnow().isoformat()+'Z','source':'ip-api'}
  else: out={'public_ip':d.get('ip',''),'isp':'','org':'','as':'','country':'','city':'','checked_at':datetime.datetime.utcnow().isoformat()+'Z','source':'ipify'}
  if out.get('public_ip') or out.get('isp'):
   print(json.dumps(save(out))); raise SystemExit
 except SystemExit: raise
 except Exception as e:
  errors.append(source+': '+str(e))
if cache: print(json.dumps(cache))
else: print(json.dumps(save(empty(errors=errors))))
PYISP
}
add_inventory_changes(){
  PAYLOAD="$1" python3 - "$INV_STATE" <<'PYINV'
import os,sys,json,datetime
path=sys.argv[1]
p=json.loads(os.environ.get('PAYLOAD','{}'))
def norm(x):
 return str(x or '').strip()
def unique(xs):
 return sorted(set([x for x in xs if x]))
def snapshot(p):
 sw=[norm(a.get('name'))+'|'+norm(a.get('version')) for a in p.get('software',{}).get('installed',[]) if isinstance(a,dict)]
 usb=[norm(u.get('type'))+'|'+norm(u.get('name'))+'|'+norm(u.get('vid'))+':'+norm(u.get('pid'))+'|'+norm(u.get('device_id')) for u in p.get('usb',{}).get('devices',[]) if isinstance(u,dict)]
 cpu=p.get('hardware',{}).get('cpu',{})
 mem=p.get('hardware',{}).get('memory',{})
 hw=['cpu='+norm(cpu.get('name')),'cores='+norm(cpu.get('cores')),'threads='+norm(cpu.get('threads')),'ram_gb='+norm(mem.get('total_gb'))]
 for g in p.get('hardware',{}).get('gpus',[]) or []:
  if isinstance(g,dict): hw.append('gpu='+norm(g.get('name'))+'|'+norm(g.get('memory_total_mb')))
 for d in p.get('storage',{}).get('disks',[]) or []:
  if isinstance(d,dict): hw.append('disk='+norm(d.get('device') or d.get('name') or d.get('mount'))+'|'+norm(d.get('total_gb'))+'|'+norm(d.get('type')))
 ips=[]
 for a in p.get('network',{}).get('adapters',[]) or []:
  if isinstance(a,dict): ips += [norm(x) for x in a.get('ips',[]) or []]
 vpn=bool(p.get('network',{}).get('vpn',{}).get('active'))
 return {'software':unique(sw),'usb':unique(usb),'hardware':unique(hw),'ips':unique(ips),'vpn_active':vpn}
def diff(old,new):
 old=set(old or []); new=set(new or [])
 return sorted(new-old), sorted(old-new)
def event(t,title,msg,add,rem):
 return {'type':t,'title':title,'message':msg,'added':add[:20],'removed':rem[:20],'created_at':datetime.datetime.utcnow().isoformat()+'Z'}
snap=snapshot(p)
changes=[]
old=None
try:
 if os.path.exists(path): old=json.load(open(path))
except Exception: old=None
if old:
 for key,title,msgname in [('usb','USB/peripheral changed','USB/peripheral'),('hardware','Hardware changed','Hardware inventory'),('software','Software changed','Software/app list'),('ips','IP address changed','IP address list')]:
  add,rem=diff(old.get(key), snap.get(key))
  if add or rem:
   ctype='ip' if key=='ips' else key
   if key=='software': msg=f'{msgname} changed: +{len(add)} installed/updated, -{len(rem)} removed'
   else: msg=f'{msgname} changed: +{len(add)} / -{len(rem)}'
   changes.append(event(ctype,title,msg,add,rem))
 if bool(old.get('vpn_active')) != bool(snap.get('vpn_active')):
  changes.append(event('vpn','VPN status changed',f"VPN is now {bool(snap.get('vpn_active'))}",[str(snap.get('vpn_active'))],[str(old.get('vpn_active'))]))
os.makedirs(os.path.dirname(path), exist_ok=True)
json.dump(snap, open(path,'w'))
p['changes']=changes
print(json.dumps(p))
PYINV
}

get_network_json(){
  rx=0; tx=0; adapters_json=$(python3 - <<'PY'
import os,json,subprocess,re
out=[]
for name in os.listdir('/sys/class/net'):
 if name=='lo': continue
 base=f'/sys/class/net/{name}'
 try: mac=open(base+'/address').read().strip()
 except: mac=''
 try: state=open(base+'/operstate').read().strip()
 except: state=''
 try: rx=int(open(base+'/statistics/rx_bytes').read().strip())
 except: rx=0
 try: tx=int(open(base+'/statistics/tx_bytes').read().strip())
 except: tx=0
 ips=[]
 try:
  s=subprocess.check_output(['ip','-4','addr','show',name], text=True, stderr=subprocess.DEVNULL)
  ips=re.findall(r'inet (\d+\.\d+\.\d+\.\d+)', s)
 except: pass
 desc=name
 low=name.lower()
 out.append({'name':name,'description':desc,'status':state,'mac':mac,'ips':ips,'is_virtual':bool(re.search(r'veth|docker|br-|virbr|vmnet|vbox|tun|tap',low)),'is_vpn':bool(re.search(r'tun|tap|wg|vpn|ppp|tailscale|zt',low)),'rx_bytes':rx,'tx_bytes':tx})
print(json.dumps(out))
PY
)
  rx=$(python3 - <<PY
import json
a=json.loads('''$adapters_json'''); print(sum(x.get('rx_bytes',0) for x in a))
PY
)
  tx=$(python3 - <<PY
import json
a=json.loads('''$adapters_json'''); print(sum(x.get('tx_bytes',0) for x in a))
PY
)
  today=$(date +%F); old_date=""; old_rx=0; old_tx=0; today_rx=0; today_tx=0; last_ts=0
  [ -f "$STATE" ] && . "$STATE"
  now_ts=$(date +%s)
  if [ -z "$last_ts" ] || [ "$last_ts" = "0" ]; then last_ts=$now_ts; fi
  if [ "$old_date" != "$today" ]; then old_date="$today"; old_rx=$rx; old_tx=$tx; today_rx=0; today_tx=0; last_ts=$now_ts; fi
  elapsed=$((now_ts-last_ts)); [ "$elapsed" -lt 1 ] && elapsed=$INTERVAL_SECONDS; [ "$elapsed" -lt 1 ] && elapsed=1
  drx=$((rx-old_rx)); dtx=$((tx-old_tx)); [ $drx -lt 0 ] && drx=0; [ $dtx -lt 0 ] && dtx=0
  down=$(awk "BEGIN{printf \"%.2f\", (($drx*8)/1024/1024)/$elapsed}"); up=$(awk "BEGIN{printf \"%.2f\", (($dtx*8)/1024/1024)/$elapsed}")
  today_rx=$((today_rx+drx)); today_tx=$((today_tx+dtx)); echo "old_date='$today'" > "$STATE"; echo "old_rx=$rx" >> "$STATE"; echo "old_tx=$tx" >> "$STATE"; echo "today_rx=$today_rx" >> "$STATE"; echo "today_tx=$today_tx" >> "$STATE"; echo "last_ts=$now_ts" >> "$STATE"
  public_json=$(get_public_internet_json)
  python3 - <<PYNET
import json
adapters=json.loads('''$adapters_json''')
ips=[]
for a in adapters: ips += a.get('ips',[])
primary=ips[0] if ips else ''
vpn=any(a.get('is_vpn') and a.get('status')=='up' for a in adapters)
public_internet=json.loads('''$public_json''')
cur_down=float('$down'); cur_up=float('$up')
traffic={'date':'$today','current_download_mbps':cur_down,'current_upload_mbps':cur_up,'today_download_gb':round($today_rx/1024/1024/1024,2),'today_upload_gb':round($today_tx/1024/1024/1024,2),'rx_total_bytes':int('$rx'),'tx_total_bytes':int('$tx'),'sample_seconds':int('$elapsed'),'note':'Current speed is average traffic since previous heartbeat; day totals reset at local midnight.'}
print(json.dumps({'primary_ip':primary,'adapters':adapters,'vpn':{'active':vpn,'detected_adapters':[a['name'] for a in adapters if a.get('is_vpn')]},'public_internet':public_internet,'internet_speed':{'download_mbps':cur_down,'upload_mbps':cur_up,'source':'live_adapter_delta','note':'Current traffic usage, not forced bandwidth speed test'},'traffic':traffic,'current_download_mbps':cur_down,'current_upload_mbps':cur_up,'today_download_gb':traffic['today_download_gb'],'today_upload_gb':traffic['today_upload_gb'],'traffic_date':'$today'}))
PYNET
}
get_software_json(){
  if command -v dpkg-query >/dev/null 2>&1; then dpkg-query -W -f='${binary:Package}\t${Version}\t${Maintainer}\n' | head -n 2000 | python3 -c 'import sys,json; out=[]
for line in sys.stdin:
 p=line.rstrip("\n").split("\t")
 if p and p[0]: out.append({"name":p[0],"version":p[1] if len(p)>1 else "","publisher":p[2] if len(p)>2 else "","install_date":""})
print(json.dumps(out))'
  else echo '[]'; fi
}
get_usb_json(){
  if command -v lsusb >/dev/null 2>&1; then lsusb | python3 -c 'import sys,json,re; out=[]
def typ(s):
 l=s.lower()
 if "keyboard" in l: return "Keyboard"
 if "mouse" in l: return "Mouse"
 if "headset" in l or "audio" in l or "microphone" in l: return "Audio"
 if "camera" in l or "webcam" in l: return "Camera"
 if "flash" in l or "storage" in l or "disk" in l: return "Storage"
 if "bluetooth" in l: return "Bluetooth"
 if "hub" in l: return "Hub"
 return "Peripheral"
for line in sys.stdin:
 m=re.search(r"ID ([0-9a-fA-F]{4}):([0-9a-fA-F]{4}) (.*)", line)
 if m: out.append({"name":m.group(3).strip(),"type":typ(m.group(3)),"class":"USB","vid":m.group(1),"pid":m.group(2),"device_id":line.strip()})
print(json.dumps(out))'
  else echo '[]'; fi
}
while true; do
  identity=$(get_identity_json); cpu=$(get_cpu_json); memory=$(get_memory_json); disks=$(get_disks_json); gpus=$(get_gpus_json); network=$(get_network_json); software=$(get_software_json); usb=$(get_usb_json)
  os_name=$(grep PRETTY_NAME /etc/os-release 2>/dev/null | cut -d= -f2- | tr -d '"')
  payload=$(python3 - <<PY
import json,datetime,platform
print(json.dumps({'schema_version':'pro-v2','timestamp':datetime.datetime.utcnow().isoformat()+'Z','agent':{'name':'CommercialMonitorPro-Ubuntu','version':'2.3-sagar-pro-message-internet-health','interval_seconds':$INTERVAL_SECONDS,'mode':'realtime_inventory_changes'},'identity':json.loads('''$identity'''),'hostname':platform.node(),'os':{'name':'$os_name','version':platform.release(),'architecture':platform.machine()},'hardware':{'cpu':json.loads('''$cpu'''),'memory':json.loads('''$memory'''),'gpus':json.loads('''$gpus''')},'storage':{'disks':json.loads('''$disks''')},'network':json.loads('''$network'''),'software':{'installed':json.loads('''$software''')},'usb':{'devices':json.loads('''$usb''')}}))
PY
)
  payload=$(add_inventory_changes "$payload")
  response=$(curl -sS -m 20 -H 'Content-Type: application/json' -d "$payload" "$SERVER_URL/api/heartbeat" 2>>"$ROOT/client_error.log")
  rc=$?
  if [ "$rc" != "0" ]; then
    echo "$(date -Is) send failed" >> "$ROOT/client_error.log"
  else
    printf '%s' "$response" | python3 - <<PYMSG >> "$ROOT/client_error.log" 2>/dev/null || true
import sys,json,subprocess,datetime,os
try:
 data=json.loads(sys.stdin.read() or '{}')
 msgs=data.get('pending_messages') or []
 for m in msgs:
  line=f"{datetime.datetime.now().isoformat()} [{m.get('priority','normal')}] {m.get('title','Admin Message')} - {m.get('message','')}"
  with open('$SERVER_MESSAGE_LOG','a',encoding='utf-8') as f: f.write(line+'\n')
  try: subprocess.run(['wall', line[:350]], timeout=3)
  except Exception: pass
except Exception as e:
 pass
PYMSG
  fi
  sleep "$INTERVAL_SECONDS"
done
